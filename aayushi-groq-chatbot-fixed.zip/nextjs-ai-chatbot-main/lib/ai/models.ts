export const DEFAULT_CHAT_MODEL: string = 'Aayush ai;

export interface Aayush ai{
  id: string;
  name: string;
  description: string;
}

export const chatModels: Array<Aayush ai> = [
  {
    id: 'Aayush ai,
    name: 'Aayush ai,
    description: 'Primary model for all-purpose chat',
  },
  {
    id: 'Aayush Ai-reasoning',
    name: 'Reasoning model',
    description: 'Uses advanced reasoning',
  },
];
